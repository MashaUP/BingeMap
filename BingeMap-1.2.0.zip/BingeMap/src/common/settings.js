// Impostazioni dell'app (nel database del profilo). Le chiavi API restano solo in locale.
import { getSetting, setSetting } from '../db/db.js';

export const DEFAULTS = {
  tmdbKey: '',
  simklClientId: '',
  googleClientId: '',
  sc: {
    origin: '',
    lang: 'it',
    strategy: 'auto', // auto | api | page
    apiPath: '/{lang}/archive', // elenco JSON paginato (intestazioni XHR); {lang} = lingua del sito
    archivePath: '/archive',
    typeParam: 'type=tv',
    pageParam: 'page', // page | offset
    pageSize: 60,
    titlePath: '/titles',
    delayMs: 1500,
    detailDelayMs: 1500,
  },
  tmdbProviders: { region: 'IT', ids: [], maxPages: 40 },
  activeCatalog: 'all', // sc | tmdbp | all
  conflictRule: 'recent', // recent | priority
  sourcePriority: ['manual', 'simkl', 'refract', 'trakt', 'tvtime', 'seriesguide', 'showly', 'sofa', 'imdb', 'csv', 'json', 'xlsx'],
  discovery: { includeWatching: false, includeHold: false, includeDropped: false },
  weights: { genre: 1, tag: 1, similar: 1, quality: 0.6, novelty: 0.3 },
  notifications: true,
  updateCheck: true,
  scheduledScan: 'off', // off | daily | weekly
  syncAuto: true,
  syncIncludeCatalog: true,
  backupReminderDays: 14,
  folderBackup: false,
  theme: 'dark',
  hideCompletedOnSite: false,
  badgesOnSite: true,
  stalledDays: 60,
  spoilerFree: false,
  myServices: [], // nomi dei fornitori legali a cui sei abbonato
  hoursPerWeek: 6,
  lang: 'it', // it | en (interfaccia)
  follows: [], // persone seguite: [{ name, kind: 'cast'|'creator', at }]
  contrast: 'normal', // normal | high
  textScale: 100, // 100 | 115 | 130
  anilistUser: '',
  settingsRev: 2,
};

// Impostazioni salvate da versioni precedenti: valori predefiniti superati che vanno aggiornati.
function migrate(stored) {
  if (!stored || typeof stored !== 'object') return stored;
  const out = { ...stored };
  if ((out.settingsRev || 1) < 2 && out.sc) {
    out.sc = { ...out.sc };
    if (out.sc.apiPath === '/api/archive') out.sc.apiPath = '/{lang}/archive';
    if (out.sc.pageParam === 'offset') out.sc.pageParam = 'page';
    out.settingsRev = 2;
  }
  return out;
}

function merge(base, over) {
  if (!over || typeof over !== 'object') return structuredClone(base);
  const out = Array.isArray(base) ? [...(over || base)] : { ...base };
  if (Array.isArray(base)) return out;
  for (const k of Object.keys(over)) {
    if (base[k] && typeof base[k] === 'object' && !Array.isArray(base[k])) out[k] = merge(base[k], over[k]);
    else out[k] = over[k];
  }
  return out;
}

export async function loadSettings() {
  return merge(DEFAULTS, migrate(await getSetting('app', {})));
}

export async function saveSettings(patch) {
  const cur = await loadSettings();
  const next = merge(cur, patch);
  await setSetting('app', next);
  return next;
}

export { merge as mergeSettings, migrate as migrateSettings };
